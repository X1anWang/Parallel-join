#ifndef LIBOBLIVIOUS_TEST_COMMON_H
#define LIBOBLIVIOUS_TEST_COMMON_H

/* Obviously, this is not secure, but it is sufficient for testing purposes. */
unsigned long get_random(void);

#endif /* liboblivious/test/common.h */
