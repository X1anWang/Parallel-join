#ifndef LIBOBLIVIOUS_TEST_ALGORITHMS_H
#define LIBOBLIVIOUS_TEST_ALGORITHMS_H

char *test_sort(void);
char *test_sort_generate_swaps(void);
char *test_compact(void);

#endif /* liboblivious/test/algorithms.h */
