#ifndef LIBOBLIVIOUS_TEST_OPAGEDMEM_H
#define LIBOBLIVIOUS_TEST_OPAGEDMEM_H

char *test_opagedmem(void);

#endif /* liboblivious/test/opagedmem.h */
