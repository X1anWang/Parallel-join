#ifndef LIBOBLIVIOUS_TEST_ORAM_H
#define LIBOBLIVIOUS_TEST_ORAM_H

char *test_oram(void);

#endif /* liboblivious/test/oram.h */
